<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-11-06 14:20:51 --> Config Class Initialized
INFO - 2019-11-06 14:20:51 --> Hooks Class Initialized
DEBUG - 2019-11-06 14:20:51 --> UTF-8 Support Enabled
INFO - 2019-11-06 14:20:51 --> Utf8 Class Initialized
INFO - 2019-11-06 14:20:51 --> URI Class Initialized
INFO - 2019-11-06 14:20:51 --> Router Class Initialized
INFO - 2019-11-06 14:20:51 --> Output Class Initialized
INFO - 2019-11-06 14:20:51 --> Security Class Initialized
DEBUG - 2019-11-06 14:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-06 14:20:51 --> Input Class Initialized
INFO - 2019-11-06 14:20:51 --> Language Class Initialized
INFO - 2019-11-06 14:20:51 --> Loader Class Initialized
INFO - 2019-11-06 14:20:51 --> Helper loaded: url_helper
INFO - 2019-11-06 14:20:51 --> Helper loaded: file_helper
INFO - 2019-11-06 14:20:51 --> Helper loaded: security_helper
INFO - 2019-11-06 14:20:51 --> Database Driver Class Initialized
DEBUG - 2019-11-06 14:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-06 14:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-06 14:20:51 --> Model "General_model" initialized
INFO - 2019-11-06 14:20:51 --> Controller Class Initialized
INFO - 2019-11-06 14:20:51 --> Model "Auth_model" initialized
INFO - 2019-11-06 14:20:51 --> Helper loaded: form_helper
INFO - 2019-11-06 14:20:51 --> Form Validation Class Initialized
INFO - 2019-11-06 14:20:51 --> Helper loaded: util_helper
INFO - 2019-11-06 14:20:51 --> File loaded: C:\xampp\htdocs\imoerams\application\views\layouts/sidebar.php
INFO - 2019-11-06 14:20:51 --> File loaded: C:\xampp\htdocs\imoerams\application\views\layouts/header.php
INFO - 2019-11-06 14:20:51 --> File loaded: C:\xampp\htdocs\imoerams\application\views\contents/eduty/stampdutyreturn.php
INFO - 2019-11-06 14:20:51 --> File loaded: C:\xampp\htdocs\imoerams\application\views\layouts/footer.php
INFO - 2019-11-06 14:20:51 --> File loaded: C:\xampp\htdocs\imoerams\application\views\layouts/jscript.php
INFO - 2019-11-06 14:20:51 --> File loaded: C:\xampp\htdocs\imoerams\application\views\template.php
INFO - 2019-11-06 14:20:51 --> Final output sent to browser
DEBUG - 2019-11-06 14:20:51 --> Total execution time: 0.1559
INFO - 2019-11-06 14:20:55 --> Config Class Initialized
INFO - 2019-11-06 14:20:55 --> Hooks Class Initialized
DEBUG - 2019-11-06 14:20:55 --> UTF-8 Support Enabled
INFO - 2019-11-06 14:20:55 --> Utf8 Class Initialized
INFO - 2019-11-06 14:20:55 --> URI Class Initialized
INFO - 2019-11-06 14:20:55 --> Router Class Initialized
INFO - 2019-11-06 14:20:55 --> Output Class Initialized
INFO - 2019-11-06 14:20:55 --> Security Class Initialized
DEBUG - 2019-11-06 14:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-06 14:20:55 --> Input Class Initialized
INFO - 2019-11-06 14:20:55 --> Language Class Initialized
INFO - 2019-11-06 14:20:55 --> Loader Class Initialized
INFO - 2019-11-06 14:20:55 --> Helper loaded: url_helper
INFO - 2019-11-06 14:20:55 --> Helper loaded: file_helper
INFO - 2019-11-06 14:20:55 --> Helper loaded: security_helper
INFO - 2019-11-06 14:20:55 --> Database Driver Class Initialized
DEBUG - 2019-11-06 14:20:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-06 14:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-06 14:20:55 --> Model "General_model" initialized
INFO - 2019-11-06 14:20:55 --> Controller Class Initialized
INFO - 2019-11-06 14:20:55 --> Model "Auth_model" initialized
ERROR - 2019-11-06 14:20:55 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\imoerams\application\controllers\app\Eduty.php 204
ERROR - 2019-11-06 14:20:55 --> Severity: Warning --> include(C:\xampp\htdocs\imoerams\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampp\htdocs\imoerams\system\core\Exceptions.php 219
ERROR - 2019-11-06 14:20:55 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\imoerams\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\imoerams\system\core\Exceptions.php 219
INFO - 2019-11-06 14:23:04 --> Config Class Initialized
INFO - 2019-11-06 14:23:05 --> Hooks Class Initialized
DEBUG - 2019-11-06 14:23:05 --> UTF-8 Support Enabled
INFO - 2019-11-06 14:23:05 --> Utf8 Class Initialized
INFO - 2019-11-06 14:23:05 --> URI Class Initialized
INFO - 2019-11-06 14:23:05 --> Router Class Initialized
INFO - 2019-11-06 14:23:05 --> Output Class Initialized
INFO - 2019-11-06 14:23:05 --> Security Class Initialized
DEBUG - 2019-11-06 14:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-06 14:23:05 --> Input Class Initialized
INFO - 2019-11-06 14:23:05 --> Language Class Initialized
INFO - 2019-11-06 14:23:05 --> Loader Class Initialized
INFO - 2019-11-06 14:23:05 --> Helper loaded: url_helper
INFO - 2019-11-06 14:23:05 --> Helper loaded: file_helper
INFO - 2019-11-06 14:23:05 --> Helper loaded: security_helper
INFO - 2019-11-06 14:23:05 --> Database Driver Class Initialized
DEBUG - 2019-11-06 14:23:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-06 14:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-06 14:23:05 --> Model Class Initialized
INFO - 2019-11-06 14:23:05 --> Controller Class Initialized
INFO - 2019-11-06 14:23:05 --> Model Class Initialized
INFO - 2019-11-06 14:23:05 --> Helper loaded: form_helper
INFO - 2019-11-06 14:23:05 --> Form Validation Class Initialized
INFO - 2019-11-06 14:23:05 --> Helper loaded: util_helper
INFO - 2019-11-06 14:23:05 --> File loaded: C:\xampp\htdocs\imoerams\application\views\layouts/sidebar.php
INFO - 2019-11-06 14:23:05 --> File loaded: C:\xampp\htdocs\imoerams\application\views\layouts/header.php
INFO - 2019-11-06 14:23:05 --> File loaded: C:\xampp\htdocs\imoerams\application\views\contents/eduty/stampdutyreturn.php
INFO - 2019-11-06 14:23:05 --> File loaded: C:\xampp\htdocs\imoerams\application\views\layouts/footer.php
INFO - 2019-11-06 14:23:05 --> File loaded: C:\xampp\htdocs\imoerams\application\views\layouts/jscript.php
INFO - 2019-11-06 14:23:05 --> File loaded: C:\xampp\htdocs\imoerams\application\views\template.php
INFO - 2019-11-06 14:23:05 --> Final output sent to browser
DEBUG - 2019-11-06 14:23:05 --> Total execution time: 0.3655
INFO - 2019-11-06 14:23:09 --> Config Class Initialized
INFO - 2019-11-06 14:23:09 --> Hooks Class Initialized
DEBUG - 2019-11-06 14:23:09 --> UTF-8 Support Enabled
INFO - 2019-11-06 14:23:09 --> Utf8 Class Initialized
INFO - 2019-11-06 14:23:09 --> URI Class Initialized
INFO - 2019-11-06 14:23:09 --> Router Class Initialized
INFO - 2019-11-06 14:23:09 --> Output Class Initialized
INFO - 2019-11-06 14:23:09 --> Security Class Initialized
DEBUG - 2019-11-06 14:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-06 14:23:09 --> Input Class Initialized
INFO - 2019-11-06 14:23:09 --> Language Class Initialized
INFO - 2019-11-06 14:23:09 --> Loader Class Initialized
INFO - 2019-11-06 14:23:09 --> Helper loaded: url_helper
INFO - 2019-11-06 14:23:09 --> Helper loaded: file_helper
INFO - 2019-11-06 14:23:09 --> Helper loaded: security_helper
INFO - 2019-11-06 14:23:09 --> Database Driver Class Initialized
DEBUG - 2019-11-06 14:23:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-06 14:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-06 14:23:09 --> Model Class Initialized
INFO - 2019-11-06 14:23:09 --> Controller Class Initialized
INFO - 2019-11-06 14:23:09 --> Model Class Initialized
INFO - 2019-11-06 14:23:09 --> Helper loaded: form_helper
INFO - 2019-11-06 14:23:09 --> Form Validation Class Initialized
INFO - 2019-11-06 14:23:09 --> Helper loaded: util_helper
INFO - 2019-11-06 14:23:10 --> File loaded: C:\xampp\htdocs\imoerams\application\views\layouts/sidebar.php
INFO - 2019-11-06 14:23:10 --> File loaded: C:\xampp\htdocs\imoerams\application\views\layouts/header.php
INFO - 2019-11-06 14:23:10 --> File loaded: C:\xampp\htdocs\imoerams\application\views\contents/eduty/stampdutyreturn.php
INFO - 2019-11-06 14:23:10 --> File loaded: C:\xampp\htdocs\imoerams\application\views\layouts/footer.php
INFO - 2019-11-06 14:23:10 --> File loaded: C:\xampp\htdocs\imoerams\application\views\layouts/jscript.php
INFO - 2019-11-06 14:23:10 --> File loaded: C:\xampp\htdocs\imoerams\application\views\template.php
INFO - 2019-11-06 14:23:10 --> Final output sent to browser
DEBUG - 2019-11-06 14:23:10 --> Total execution time: 0.5559
INFO - 2019-11-06 14:23:14 --> Config Class Initialized
INFO - 2019-11-06 14:23:14 --> Hooks Class Initialized
DEBUG - 2019-11-06 14:23:14 --> UTF-8 Support Enabled
INFO - 2019-11-06 14:23:14 --> Utf8 Class Initialized
INFO - 2019-11-06 14:23:14 --> URI Class Initialized
INFO - 2019-11-06 14:23:14 --> Router Class Initialized
INFO - 2019-11-06 14:23:14 --> Output Class Initialized
INFO - 2019-11-06 14:23:14 --> Security Class Initialized
DEBUG - 2019-11-06 14:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-06 14:23:14 --> Input Class Initialized
INFO - 2019-11-06 14:23:14 --> Language Class Initialized
INFO - 2019-11-06 14:23:14 --> Loader Class Initialized
INFO - 2019-11-06 14:23:14 --> Helper loaded: url_helper
INFO - 2019-11-06 14:23:14 --> Helper loaded: file_helper
INFO - 2019-11-06 14:23:14 --> Helper loaded: security_helper
INFO - 2019-11-06 14:23:14 --> Database Driver Class Initialized
DEBUG - 2019-11-06 14:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-06 14:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-06 14:23:14 --> Model Class Initialized
INFO - 2019-11-06 14:23:14 --> Controller Class Initialized
INFO - 2019-11-06 14:23:14 --> Model Class Initialized
INFO - 2019-11-06 14:23:14 --> Helper loaded: form_helper
INFO - 2019-11-06 14:23:14 --> Form Validation Class Initialized
INFO - 2019-11-06 14:23:14 --> Helper loaded: util_helper
INFO - 2019-11-06 14:23:15 --> File loaded: C:\xampp\htdocs\imoerams\application\views\layouts/sidebar.php
INFO - 2019-11-06 14:23:15 --> File loaded: C:\xampp\htdocs\imoerams\application\views\layouts/header.php
INFO - 2019-11-06 14:23:15 --> File loaded: C:\xampp\htdocs\imoerams\application\views\contents/eduty/stampdutyreturn.php
INFO - 2019-11-06 14:23:15 --> File loaded: C:\xampp\htdocs\imoerams\application\views\layouts/footer.php
INFO - 2019-11-06 14:23:15 --> File loaded: C:\xampp\htdocs\imoerams\application\views\layouts/jscript.php
INFO - 2019-11-06 14:23:15 --> File loaded: C:\xampp\htdocs\imoerams\application\views\template.php
INFO - 2019-11-06 14:23:15 --> Final output sent to browser
DEBUG - 2019-11-06 14:23:15 --> Total execution time: 0.2458
INFO - 2019-11-06 14:23:20 --> Config Class Initialized
INFO - 2019-11-06 14:23:20 --> Hooks Class Initialized
DEBUG - 2019-11-06 14:23:20 --> UTF-8 Support Enabled
INFO - 2019-11-06 14:23:20 --> Utf8 Class Initialized
INFO - 2019-11-06 14:23:20 --> URI Class Initialized
INFO - 2019-11-06 14:23:20 --> Router Class Initialized
INFO - 2019-11-06 14:23:20 --> Output Class Initialized
INFO - 2019-11-06 14:23:20 --> Security Class Initialized
DEBUG - 2019-11-06 14:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-06 14:23:20 --> Input Class Initialized
INFO - 2019-11-06 14:23:20 --> Language Class Initialized
INFO - 2019-11-06 14:23:20 --> Loader Class Initialized
INFO - 2019-11-06 14:23:20 --> Helper loaded: url_helper
INFO - 2019-11-06 14:23:20 --> Helper loaded: file_helper
INFO - 2019-11-06 14:23:20 --> Helper loaded: security_helper
INFO - 2019-11-06 14:23:20 --> Database Driver Class Initialized
DEBUG - 2019-11-06 14:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-06 14:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-06 14:23:20 --> Model Class Initialized
INFO - 2019-11-06 14:23:20 --> Controller Class Initialized
INFO - 2019-11-06 14:23:20 --> Model Class Initialized
ERROR - 2019-11-06 14:23:20 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\imoerams\application\controllers\app\Eduty.php 204
ERROR - 2019-11-06 14:23:20 --> Severity: Warning --> include(C:\xampp\htdocs\imoerams\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampp\htdocs\imoerams\system\core\Exceptions.php 219
ERROR - 2019-11-06 14:23:20 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\imoerams\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\imoerams\system\core\Exceptions.php 219
INFO - 2019-11-06 14:31:15 --> Config Class Initialized
INFO - 2019-11-06 14:31:15 --> Hooks Class Initialized
DEBUG - 2019-11-06 14:31:15 --> UTF-8 Support Enabled
INFO - 2019-11-06 14:31:15 --> Utf8 Class Initialized
INFO - 2019-11-06 14:31:15 --> URI Class Initialized
INFO - 2019-11-06 14:31:15 --> Router Class Initialized
INFO - 2019-11-06 14:31:15 --> Output Class Initialized
INFO - 2019-11-06 14:31:15 --> Security Class Initialized
DEBUG - 2019-11-06 14:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-06 14:31:15 --> Input Class Initialized
INFO - 2019-11-06 14:31:15 --> Language Class Initialized
INFO - 2019-11-06 14:31:15 --> Loader Class Initialized
INFO - 2019-11-06 14:31:15 --> Helper loaded: url_helper
INFO - 2019-11-06 14:31:15 --> Helper loaded: file_helper
INFO - 2019-11-06 14:31:15 --> Helper loaded: security_helper
INFO - 2019-11-06 14:31:15 --> Database Driver Class Initialized
DEBUG - 2019-11-06 14:31:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-06 14:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-06 14:31:15 --> Model Class Initialized
INFO - 2019-11-06 14:31:15 --> Controller Class Initialized
INFO - 2019-11-06 14:31:15 --> Model Class Initialized
INFO - 2019-11-06 14:31:15 --> Helper loaded: form_helper
INFO - 2019-11-06 14:31:15 --> Form Validation Class Initialized
INFO - 2019-11-06 14:31:15 --> Helper loaded: util_helper
INFO - 2019-11-06 14:31:15 --> File loaded: C:\xampp\htdocs\imoerams\application\views\layouts/sidebar.php
INFO - 2019-11-06 14:31:15 --> File loaded: C:\xampp\htdocs\imoerams\application\views\layouts/header.php
INFO - 2019-11-06 14:31:15 --> File loaded: C:\xampp\htdocs\imoerams\application\views\contents/eduty/stampdutyreturn.php
INFO - 2019-11-06 14:31:15 --> File loaded: C:\xampp\htdocs\imoerams\application\views\layouts/footer.php
INFO - 2019-11-06 14:31:15 --> File loaded: C:\xampp\htdocs\imoerams\application\views\layouts/jscript.php
INFO - 2019-11-06 14:31:15 --> File loaded: C:\xampp\htdocs\imoerams\application\views\template.php
INFO - 2019-11-06 14:31:15 --> Final output sent to browser
DEBUG - 2019-11-06 14:31:15 --> Total execution time: 0.1592
INFO - 2019-11-06 14:31:26 --> Config Class Initialized
INFO - 2019-11-06 14:31:26 --> Hooks Class Initialized
DEBUG - 2019-11-06 14:31:26 --> UTF-8 Support Enabled
INFO - 2019-11-06 14:31:26 --> Utf8 Class Initialized
INFO - 2019-11-06 14:31:26 --> URI Class Initialized
INFO - 2019-11-06 14:31:26 --> Router Class Initialized
INFO - 2019-11-06 14:31:26 --> Output Class Initialized
INFO - 2019-11-06 14:31:26 --> Security Class Initialized
DEBUG - 2019-11-06 14:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-06 14:31:26 --> Input Class Initialized
INFO - 2019-11-06 14:31:26 --> Language Class Initialized
INFO - 2019-11-06 14:31:26 --> Loader Class Initialized
INFO - 2019-11-06 14:31:26 --> Helper loaded: url_helper
INFO - 2019-11-06 14:31:26 --> Helper loaded: file_helper
INFO - 2019-11-06 14:31:26 --> Helper loaded: security_helper
INFO - 2019-11-06 14:31:26 --> Database Driver Class Initialized
DEBUG - 2019-11-06 14:31:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-06 14:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-06 14:31:26 --> Model Class Initialized
INFO - 2019-11-06 14:31:26 --> Controller Class Initialized
INFO - 2019-11-06 14:31:26 --> Model Class Initialized
ERROR - 2019-11-06 14:31:26 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\imoerams\application\controllers\app\Eduty.php 204
ERROR - 2019-11-06 14:31:26 --> Severity: Warning --> include(C:\xampp\htdocs\imoerams\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampp\htdocs\imoerams\system\core\Exceptions.php 219
ERROR - 2019-11-06 14:31:26 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\imoerams\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\imoerams\system\core\Exceptions.php 219
INFO - 2019-11-06 14:32:59 --> Config Class Initialized
INFO - 2019-11-06 14:32:59 --> Hooks Class Initialized
DEBUG - 2019-11-06 14:32:59 --> UTF-8 Support Enabled
INFO - 2019-11-06 14:32:59 --> Utf8 Class Initialized
INFO - 2019-11-06 14:32:59 --> URI Class Initialized
INFO - 2019-11-06 14:32:59 --> Router Class Initialized
INFO - 2019-11-06 14:32:59 --> Output Class Initialized
INFO - 2019-11-06 14:32:59 --> Security Class Initialized
DEBUG - 2019-11-06 14:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-06 14:32:59 --> Input Class Initialized
INFO - 2019-11-06 14:32:59 --> Language Class Initialized
INFO - 2019-11-06 14:32:59 --> Loader Class Initialized
INFO - 2019-11-06 14:32:59 --> Helper loaded: url_helper
INFO - 2019-11-06 14:32:59 --> Helper loaded: file_helper
INFO - 2019-11-06 14:32:59 --> Helper loaded: security_helper
INFO - 2019-11-06 14:32:59 --> Database Driver Class Initialized
DEBUG - 2019-11-06 14:32:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-06 14:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-06 14:32:59 --> Model Class Initialized
INFO - 2019-11-06 14:32:59 --> Controller Class Initialized
INFO - 2019-11-06 14:32:59 --> Model Class Initialized
INFO - 2019-11-06 14:32:59 --> Helper loaded: form_helper
INFO - 2019-11-06 14:32:59 --> Form Validation Class Initialized
INFO - 2019-11-06 14:32:59 --> Helper loaded: util_helper
INFO - 2019-11-06 14:32:59 --> File loaded: C:\xampp\htdocs\imoerams\application\views\layouts/sidebar.php
INFO - 2019-11-06 14:32:59 --> File loaded: C:\xampp\htdocs\imoerams\application\views\layouts/header.php
INFO - 2019-11-06 14:33:00 --> File loaded: C:\xampp\htdocs\imoerams\application\views\contents/eduty/stampdutyreturn.php
INFO - 2019-11-06 14:33:00 --> File loaded: C:\xampp\htdocs\imoerams\application\views\layouts/footer.php
INFO - 2019-11-06 14:33:00 --> File loaded: C:\xampp\htdocs\imoerams\application\views\layouts/jscript.php
INFO - 2019-11-06 14:33:00 --> File loaded: C:\xampp\htdocs\imoerams\application\views\template.php
INFO - 2019-11-06 14:33:00 --> Final output sent to browser
DEBUG - 2019-11-06 14:33:00 --> Total execution time: 0.1516
INFO - 2019-11-06 14:33:15 --> Config Class Initialized
INFO - 2019-11-06 14:33:15 --> Hooks Class Initialized
DEBUG - 2019-11-06 14:33:15 --> UTF-8 Support Enabled
INFO - 2019-11-06 14:33:15 --> Utf8 Class Initialized
INFO - 2019-11-06 14:33:15 --> URI Class Initialized
INFO - 2019-11-06 14:33:15 --> Router Class Initialized
INFO - 2019-11-06 14:33:15 --> Output Class Initialized
INFO - 2019-11-06 14:33:15 --> Security Class Initialized
DEBUG - 2019-11-06 14:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-06 14:33:15 --> Input Class Initialized
INFO - 2019-11-06 14:33:15 --> Language Class Initialized
INFO - 2019-11-06 14:33:15 --> Loader Class Initialized
INFO - 2019-11-06 14:33:15 --> Helper loaded: url_helper
INFO - 2019-11-06 14:33:15 --> Helper loaded: file_helper
INFO - 2019-11-06 14:33:15 --> Helper loaded: security_helper
INFO - 2019-11-06 14:33:15 --> Database Driver Class Initialized
DEBUG - 2019-11-06 14:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-11-06 14:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-11-06 14:33:15 --> Model Class Initialized
INFO - 2019-11-06 14:33:15 --> Controller Class Initialized
INFO - 2019-11-06 14:33:15 --> Model Class Initialized
ERROR - 2019-11-06 14:33:15 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\imoerams\application\controllers\app\Eduty.php 204
ERROR - 2019-11-06 14:33:15 --> Severity: Warning --> include(C:\xampp\htdocs\imoerams\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampp\htdocs\imoerams\system\core\Exceptions.php 219
ERROR - 2019-11-06 14:33:15 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\imoerams\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\imoerams\system\core\Exceptions.php 219

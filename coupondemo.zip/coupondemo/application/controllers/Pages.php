<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
* 
*/

class Pages extends CI_Controller {
	private $active = 4;
	private $formtitle = "";
	private $breadcrumb = "";
	private $assVal = 'pages';
	
	public function __construct()
	{
		parent::__construct();

		$this->load->model('Page_model');
	}

	public function index(){
		$pagevar = array();

		$this->formtitle = "Shop Cart";
		$pagevar['title'] = $this->formtitle;
		$data['js'] = "shopcart";

		$pagevar['page'] = 'contents/pages/shopcart';
		$this->load->view('template', $pagevar);
	}

	public function coupons(){
		$data = array();

		$this->formtitle = "Coupons List";
		$data['title'] = $this->formtitle;
		$data['js'] = "coupon";
		$data['record_list'] = $this->Page_model->coupon_list();
        
		$data['page'] = 'contents/pages/couponslist';
		$this->load->view('template',$data);
	}

	public function newcoupon(){
		$data = array();

		$data['page'] = 'contents/pages/newcoupon';
		$this->formtitle = "New Coupon";
		$data['title'] = $this->formtitle;
		$data['js'] = "coupon";
		$this->load->library('form_validation');
		$data['discount_type'] = $this->Page_model->get_discount_type();

		if(isset($_POST['seenfr'])):
			$this->form_validation->set_rules("txtcouponcode","Coupon Code","trim|required");
			$this->form_validation->set_rules("txtcouponname","Coupon Name","trim|required");
			$this->form_validation->set_rules("seldiscountype","Discount Type","trim|required");
			$this->form_validation->set_rules("txtmincartamount","Minimum Cart Amount","trim|numeric");
			$this->form_validation->set_rules("txtmincartitem","Minimum Cart Item","trim|numeric");

			if($this->input->post('seldiscountype') == "1" || $this->input->post('seldiscountype') == "2"){
				$this->form_validation->set_rules("txtdiscount1","Discount Amount","trim|required|numeric");
			}

			if($this->input->post('seldiscountype') == "3"){
				$this->form_validation->set_rules("txtdiscount1","Discount Amount","trim|required|numeric");
				$this->form_validation->set_rules("txtdiscount2","Discount Amount","trim|required|numeric");
			}

			if($this->form_validation->run() === FALSE){
				$data['msg'] = "Please deal with the errors below";
				echo validation_errors();
				exit;
			}
			else{
				$couponcode = $this->security->xss_clean($this->input->post('txtcouponcode'));

				if($this->Page_model->verify_coupon_code($couponcode)){
					echo("COUPON CODE ALREADY EXIST");
					exit;
				}

				$fixed_value = 0;
				$percent_value = 0;

				if($this->input->post('seldiscountype') == "1"){
					$fixed_value = $this->security->xss_clean($this->input->post('txtdiscount1'));
				}

				if($this->input->post('seldiscountype') == "2"){
					$percent_value = $this->security->xss_clean($this->input->post('txtdiscount1'));
				}

				if($this->input->post('seldiscountype') == "3"){
					$fixed_value = $this->security->xss_clean($this->input->post('txtdiscount1'));
					$percent_value = $this->security->xss_clean($this->input->post('txtdiscount2'));
				}

				$this->db->trans_begin();//begin transaction

				$arr = array();

				$arr['coupon_code'] = $couponcode;
				$arr['descrp'] = $this->security->xss_clean($this->input->post('txtcouponname'));
				$arr['discount_type'] = $this->input->post('seldiscountype');
				$arr['min_cart_amount'] = $this->security->xss_clean($this->input->post('txtmincartamount'));
				$arr['min_cart_item'] = $this->security->xss_clean($this->input->post('txtmincartitem'));
				$arr['fixed_value'] = $fixed_value;
				$arr['percent_value'] = $percent_value;
				$arr['created'] = time();
				
				$this->db->insert('tbl_coupons',$arr);

				if ($this->db->trans_status() === FALSE)
				{
					$this->db->trans_rollback();
					echo "SOMETHING WENT WRONG|error";exit;
				}

				if($this->db->affected_rows() > 0)
				{
					$this->db->trans_complete();

					echo "COUPON WAS SUCCESSFULLY CREATED|success";
					exit;
				}
			}
		endif;

		$this->load->view('template',$data);	
	}
}
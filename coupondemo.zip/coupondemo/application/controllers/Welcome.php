<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	
	public function __construct()
	{
		parent::__construct();
		
		$this->load->model('Auth_model');
		$this->load->model('General_model');
	}

	public function index()
	{
		$pagevar = array();
		$pagevar['news'] = $this->General_model->get_news();
		$pagevar['officials'] = $this->General_model->get_officials();
		
		$pagevar['title'] = "NNPC COOP MOSIMI";
		// $site_settings = $this->Auth_model->get_site_settings();

		// $sess_arr = array(
		// 	'sitename'=>$site_settings->sitename,
		// 	'revenueservice'=>$site_settings->revenueservice,
		// 	'statename'=>$site_settings->statename,
		// 	'address'=>$site_settings->address,
		// 	'vendorname'=>$site_settings->vendorname,
		// 	'sitefullname'=>$site_settings->fullsitename
		// );
		// $this->session->set_userdata($sess_arr);
		$pagevar['page'] = 'contents/homepage';
		$this->load->view('template', $pagevar);
	}
}

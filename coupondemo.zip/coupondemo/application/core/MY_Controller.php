<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class MY_Controller extends CI_Controller{

    private $content_view = 'crud_view';
    protected $state_id;
    protected $_title = 'eDAP';

    function __construct(){
        parent::__construct();
        $this->state_id = $this->session->userdata('state_id');
        $this->unsetUsedSession();
        //$this->checkLoginStatus();
    }

    public function ifPageExist($page){
        if(!file_exists(APPPATH.'views/contents/'.$page.'.php'))
        {
            // Whoops, we don't have a page for that!
            show_404();
        }
    }

    public function isloggedIn(){
        $email = $this->session->userdata('email');
        if($email){
            return true;
        }
        return false;
    }

    public function checkLogin(){
        $userid = $this->session->userdata('email');

        if(!$this->isloggedIn()){
            echo "hi";exit;
            redirect('app/auth');
        }
        else{
            $set = $this->Auth_model->setLoggedin($userid);
            $bool = $this->login_session();

            if($bool == "empty"):
                 $this->signout();
            endif;

            if($bool != false){
                $x = $this->Auth_model->loginTime();
            }
            else{
                echo "hie";exit;
                $this->signout();
            }
        }
    }

    public function login_session(){
        $this->load->model('Auth_model');
        $check = $this->Auth_model->checkLoginTime();
        $bool = "";
        if(!$check){
            return false;
        }
        else{
            $bool = $this->Auth_model->loginTime();
        }
        return $bool;
    }

    public function checkLoginStatus(){
        $this->load->model('Auth_model');
        $bool = true;
        $check = $this->Auth_model->expired();
        $email = $this->session->userdata('email');
        if(!$this->session->userdata('loggedin')){
            //redirect('');
            $bool = false;
        }

        if(!$check){
            $bool = false;
        }

        if(!$bool){
            $this->signout();
        }
        else{
            $this->Auth_model->updateTime();
        }
    }

    public function signout(){
        $this->load->model('Auth_model');
        $email = $this->session->userdata('email');
        $this->session->unset_userdata('loggedin');
        $this->Auth_model->setLogout($email);
        $this->Auth_model->deleteLoggedInTime($email);
        $this->session->sess_destroy();
        redirect('');
    }

    public function do_uploadxx($filename) { 
        $config['upload_path']   = './uploads/'; 
        $config['allowed_types'] = 'gif|jpg|png'; 
        $config['max_size']      = 2048; 
        $config['max_width']     = 1024; 
        $config['max_height']    = 768; 
        $config['remove_spaces'] = true;
        $config['file_name'] = substr(md5(rand()), 0, 20);

        $this->load->library('upload', $config);

        if( ! $this->upload->do_upload($filename)){
            $error = array('error' => $this->upload->display_errors()); 
            return false;
        }
        else { 
            $data = array('upload_data' => $this->upload->data()); 
            return $data;
        } 
    } 

    private function unsetUsedSession(){
        $arr = array("pkey"=>"");
        $this->session->unset_userdata($arr);
    }

    public function pageLoader($output,$data){
        $output->data = $data;
        $output->content_view = $this->content_view;
        $this->load->view('contents/templateCrud',$output);
    }


    public function formatStrNo($str_no){
        return str_replace(",", "", str_replace(".00", "", $str_no));
    }

    public function readable_random_string($length = 6)
    { 
        $string = '';
        $vowels = array("a","e","i","o","u");  
        $consonants = array('b', 'c', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'm', 'n', 'p', 'r', 's', 't', 'v', 'w', 'x', 'y', 'z');  

        // Seeding goes on here
        srand((double) microtime() * 1000000);
        $max = $length/2;

        for ($i = 1; $i <= $max; $i++)
        {
            $string .= $consonants[rand(0,19)];
            $string .= $vowels[rand(0,4)];
        }
        return strtoupper($string);
    }

    public function do_upload($namefield = 'input-file-preview',$path = './assets/uploads/updates') { 
        $this->load->helper('string');
        $filename = random_string('unique'); 
        $config['upload_path']   = $path; 
        $config['allowed_types'] = 'gif|jpg|png'; 
        $config['file_name'] = $filename;
        $config['max_size']      = 1024; 
        $config['max_width']     = 2048; 
        $config['max_height']    = 2048;  

        $this->load->library('upload', $config);  

        if ( !$this->upload->do_upload($namefield)) {
            $error = array('error' => $this->upload->display_errors()); 
            return array(false,$error); 
        }
        else { 
            $data = array('upload_data' => $this->upload->data()); 
            return array(true,$data);
        } 
    }

    //arr
    public function do_uploadArr($namefield = 'input-file-preview',$path) {
        $config = array();
        $this->load->library('upload');
        $this->load->helper('string');
        $filename = random_string('unique'); 
        $config['upload_path']   = $path; 
        $config['allowed_types'] = 'gif|jpg|png|jpeg'; 
        $config['file_name'] = $filename;
        $config['max_size']      = 0; 
        $config['max_width']     = 0; 
        $config['max_height']    = 0;  

        $this->upload->initialize($config);

        if ( !$this->upload->do_upload($namefield)) {
            //$error = array('error' => $this->upload->display_errors()); 
            return array(false,$this->upload->display_errors());
        }
        else{
            $data = array('upload_data' => $this->upload->data()); 
            return array(true,$data);
        }
    }

    //QR code guy
    public function qr_code($arr){
        $this->load->library('ciqrcode');

        header("Content-Type: image/png");

        $link = $arr[0];

        $data_content = " ".$link."\n";
        $params['level'] = 'H';
        $params['size'] = 4;
        $params['data'] = $data_content;

        return $this->ciqrcode->generate($params);  
    }

    public function translateToWords($number) 
    {
        $max_size = pow(10,18);
        if (!$number) return "zero";
        if (is_int($number) && $number < abs($max_size)) 
        {            
            switch ($number) 
            {
                // set up some rules for converting digits to words
                case $number < 0:
                    $prefix = "negative";
                    $suffix = translateToWords(-1*$number);
                    $string = $prefix . " " . $suffix;
                break;

                case 1:
                    $string = "one";
                break;

                case 2:
                    $string = "two";
                break;

                case 3:
                    $string = "three";
                break;

                case 4: 
                    $string = "four";
                break;

                case 5:
                    $string = "five";
                break;

                case 6:
                    $string = "six";
                break;

                case 7:
                    $string = "seven";
                break;

                case 8:
                    $string = "eight";
                break;

                case 9:
                    $string = "nine";
                break;                

                case 10:
                    $string = "ten";
                break;            

                case 11:
                    $string = "eleven";
                break;            

                case 12:
                    $string = "twelve";
                break;            

                case 13:
                    $string = "thirteen";
                break;            

                case 13:
                    $string = "fourteen";
                break;

                case 15:
                    $string = "fifteen";
                break;            

                case $number < 20:
                    $string = translateToWords($number%10);
                    // eighteen only has one "t"
                    if ($number == 18){
                        $suffix = "een";
                    } 
                    else  {
                        $suffix = "teen";
                    }

                    $string .= $suffix;
                break;

                case 20:
                    $string = "twenty";
                break;            

                case 30:
                    $string = "thirty";
                break;            

                case 40:
                    $string = "forty";
                break;            

                case 50:
                    $string = "fifty";
                break;            

                case 60:
                    $string = "sixty";
                break;            

                case 70:
                    $string = "seventy";
                break;            

                case 80:
                    $string = "eighty";
                break;            

                case 90:
                    $string = "ninety";
                break;                

                case $number < 100:
                    $prefix = translateToWords($number-$number%10);
                    $suffix = translateToWords($number%10);
                    $string = $prefix . "-" . $suffix;
                break;

                // handles all number 100 to 999
                case $number < pow(10,3):                    
                    // floor return a float not an integer
                    $prefix = translateToWords(intval(floor($number/pow(10,2)))) . " hundred";
                    if ($number%pow(10,2)) $suffix = " and " . translateToWords($number%pow(10,2));
                        $string = $prefix . $suffix;
                break;

                case $number < pow(10,6):
                    // floor return a float not an integer
                    $prefix = translateToWords(intval(floor($number/pow(10,3)))) . " thousand";
                    if ($number%pow(10,3)) $suffix = translateToWords($number%pow(10,3));
                        $string = $prefix . " " . $suffix;
                break;

                case $number < pow(10,9):
                    // floor return a float not an integer
                    $prefix = translateToWords(intval(floor($number/pow(10,6)))) . " million";
                    if ($number%pow(10,6)) $suffix = translateToWords($number%pow(10,6));
                        $string = $prefix . " " . $suffix;
                break;                    

                case $number < pow(10,12):
                    // floor return a float not an integer
                    $prefix = translateToWords(intval(floor($number/pow(10,9)))) . " billion";
                    if ($number%pow(10,9)) $suffix = translateToWords($number%pow(10,9));
                        $string = $prefix . " " . $suffix;    
                break;

                case $number < pow(10,15):
                    // floor return a float not an integer
                    $prefix = translateToWords(intval(floor($number/pow(10,12)))) . " trillion";
                    if ($number%pow(10,12)) $suffix = translateToWords($number%pow(10,12));
                        $string = $prefix . " " . $suffix;    
                break;        
                // Be careful not to pass default formatted numbers in the quadrillions+ into this function
                // Default formatting is float and causes errors
                case $number < pow(10,18):
                    // floor return a float not an integer
                    $prefix = translateToWords(intval(floor($number/pow(10,15)))) . " quadrillion";
                    if ($number%pow(10,15)) $suffix = translateToWords($number%pow(10,15));
                        $string = $prefix . " " . $suffix;    
                break;                    
            }
        } 
        else{
            echo "ERROR with - $number<br/> Number must be an integer between -" . number_format($max_size, 0, ".", ",") . " and " . number_format($max_size, 0, ".", ",") . " exclussive.";
        }
        return $string;    
    }

    public function numbers($tot){
        return substr(number_format(time() * rand(),0,'',''),0,$tot);
    }

    public function specialNos($tot){
        return str_pad(mt_rand(0, 99999999), $tot, '0', STR_PAD_LEFT);
    }

    function convert_number_to_words($number) {
        $hyphen      = ' - ';
        $conjunction = ' and ';
        $separator   = ', ';
        $negative    = 'negative ';
        $decimal     = ' point ';
        $dictionary  = array(
            0                   => 'zero',
            1                   => 'one',
            2                   => 'two',
            3                   => 'three',
            4                   => 'four',
            5                   => 'five',
            6                   => 'six',
            7                   => 'seven',
            8                   => 'eight',
            9                   => 'nine',
            10                  => 'ten',
            11                  => 'eleven',
            12                  => 'twelve',
            13                  => 'thirteen',
            14                  => 'fourteen',
            15                  => 'fifteen',
            16                  => 'sixteen',
            17                  => 'seventeen',
            18                  => 'eighteen',
            19                  => 'nineteen',
            20                  => 'twenty',
            30                  => 'thirty',
            40                  => 'fourty',
            50                  => 'fifty',
            60                  => 'sixty',
            70                  => 'seventy',
            80                  => 'eighty',
            90                  => 'ninety',
            100                 => 'hundred',
            1000                => 'thousand',
            1000000             => 'million',
            1000000000          => 'billion',
            1000000000000       => 'trillion',
            1000000000000000    => 'quadrillion',
            1000000000000000000 => 'quintillion'
        );

        if (!is_numeric($number)) {
            return false;
        }

        if (($number >= 0 && (int) $number < 0) || (int) $number < 0 - PHP_INT_MAX) {
            // overflow
            trigger_error(
                'convert_number_to_words only accepts numbers between -' . PHP_INT_MAX . ' and ' . PHP_INT_MAX,
                E_USER_WARNING
            );
            return false;
        }

        if ($number < 0) {
            return $negative . $this->convert_number_to_words(abs($number));
        }

        $string = $fraction = null;
        if (strpos($number, '.') !== false) {
            list($number, $fraction) = explode('.', $number);
        }

        switch (true) {
            case $number < 21:
            $string = $dictionary[$number];
            break;

            case $number < 100:
                $tens   = ((int) ($number / 10)) * 10;
                $units  = $number % 10;
                $string = $dictionary[$tens];

                if ($units) {
                    $string .= $hyphen . $dictionary[$units];
                }
            break;

            case $number < 1000:
                $hundreds  = $number / 100;
                $remainder = $number % 100;
                $string = $dictionary[$hundreds] . ' ' . $dictionary[100];

                if ($remainder) {
                    $string .= $conjunction . $this->convert_number_to_words($remainder);
                }
            break;

            default:
                $baseUnit = pow(1000, floor(log($number, 1000)));
                $numBaseUnits = (int) ($number / $baseUnit);
                $remainder = $number % $baseUnit;
                $string = $this->convert_number_to_words($numBaseUnits) . ' ' . $dictionary[$baseUnit];
                if ($remainder) {
                    $string .= $remainder < 100 ? $conjunction : $separator;
                    $string .= $this->convert_number_to_words($remainder);
                }
            break;
        }

        if (null !== $fraction && is_numeric($fraction)) {
            $string .= $decimal;
            $words = array();
            foreach (str_split((string) $fraction) as $number) {
                $words[] = $dictionary[$number];
            }
            $string .= implode(' ', $words);
        }
        return $string;
    }
}
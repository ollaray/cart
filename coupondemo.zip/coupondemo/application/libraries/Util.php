<?php

defined('BASEPATH') OR exit('No direct script access allowed');


class Util
{
	
	function __construct()
	{
		# code...
	}

    public function generate_numbers($start, $count, $digits) {
       $result = "";
       for ($n = $start; $n < $start + $count; $n++) {
     
          $result = str_pad($n, $digits, "0", STR_PAD_LEFT);
     
       }
       return $result;
    }
    
    public function relocatefies($srcdirectory, $newfiledirectory){
        $result = 0;
        $prefixname = "";
        $dirname = "";

        if(empty($srcdirectory)){
            return "PLEASE PROVIDE SOURCE DIRECTORY"; exit;
        }

        if(!is_array($newfiledirectory) || empty($newfiledirectory)){
            return "PLEASE PROVIDE AN ASSOCIATIVE ARRAY SPECIFYING FILE TYPE AND DESIRED NEW DIRECTORY"; exit;
        }

        $dir = $srcdirectory;//"path/to/targetFiles";
        $altpath = "./assets/uploads/voldsurvey";

        /*******************FIRST LEVEL*********************/
        if (is_dir($dir)) {
            if ($dh = opendir($dir)) {
                while (($file = readdir($dh)) !== false) {
                    if ($file==".") continue;
                    if ($file=="..") continue;
                    if ($file=="index.html") continue;

                    /*******************SECOND LEVEL*********************/
                    if (is_dir($dir.'/'.$file)) {
                        
                        $dirname = $file;
                        
                        if ($openfile = opendir($dir.'/'.$file)) {
                            while (($innerfile = readdir($openfile)) !== false) {
                                if ($innerfile==".") continue;
                                if ($innerfile=="..") continue;
                                if ($innerfile=="index.html") continue;

                                /**********************THIRD LEVEL*********************/
                                if (is_dir($dir.'/'.$file.'/'.$innerfile)) {
                        
                                    $innerdirname = $innerfile;
                                    
                                    if ($openinnerfile = opendir($dir.'/'.$file.'/'.$innerfile)) {
                                        while (($innermostfile = readdir($openinnerfile)) !== false) {
                                            if ($innermostfile==".") continue;
                                            if ($innermostfile=="..") continue;
                                            if ($innermostfile=="index.html") continue;

                                            $badstrng = array("New folder","- Copy","(",")","PAGE","page","PAGE ","page ","pg ","PG "," ");
                                            $prefixname = strtolower(str_replace($badstrng, '', ($dirname."__".$innerdirname."__".$innermostfile)));
                                           // $result .= $dirname.$innerdirname.$innermostfile ."<br/>";

                                            foreach($newfiledirectory as $filename => $fileloc) {
                                                if (strpos($prefixname, 'survey') === false) {
                                                    continue;
                                                }

                                                if (strpos(strtolower($innermostfile), $filename) !== false) {
                                                    if (rename($dir.'/'.$dirname.'/'.$innerdirname.'/'.$innermostfile, $fileloc.'/'.$prefixname))
                                                    {
                                                        $result++;
                                                    }
                                                    else {
                                                        return "FILE COULD NOT COPIED"; exit;
                                                    }
                                                }
                                                else{
                                                    if (rename($dir.'/'.$dirname.'/'.$innerdirname.'/'.$innermostfile, $altpath.'/'.$prefixname))
                                                    {
                                                        $result++;
                                                    }
                                                    else {
                                                        return "FILE COULD NOT COPIED"; exit;
                                                    }
                                                }     
                                            }
                                        }
                                        closedir($openinnerfile);
                                    }
                                }
                                else
                                {
                                    $prefixname = strtolower(str_replace(' ', '', ($dirname."__".$innerfile)));
                                    //$result .= $dirname.$innerfile ."<br/>";

                                    foreach($newfiledirectory as $filename => $fileloc) {
                                        if (strpos(strtolower($innerfile), $filename) !== false) {
                                            if (rename($dir.'/'.$dirname.'/'.$innerfile, $fileloc.'/'.$prefixname))
                                            {
                                                $result++;
                                            }
                                            else {
                                                return "FILE COULD NOT COPIED"; exit;
                                            }
                                        }
                                        else{
                                            if (rename($dir.'/'.$dirname.'/'.$innerfile, $altpath.'/'.$prefixname))
                                            {
                                                $result++;
                                            }
                                            else {
                                                return "FILE COULD NOT COPIED"; exit;
                                            }
                                        }     
                                    }
                                }
                                /*******************************************/
                            }
                            closedir($openfile);
                        }
                    }
                    else
                    {
                        $prefixname = strtolower(str_replace(' ', '', ($file)));
                        //$result .= $file ."<br/>";

                        foreach($newfiledirectory as $filename => $fileloc) {
                            if (strpos(strtolower($file), $filename) !== false) {
                                if (rename($dir.'/'.$file, $fileloc.'/'.$prefixname))
                                {
                                    $result++;
                                }
                                else {
                                    return "FILE COULD NOT COPIED"; exit;
                                }
                            }
                            else{
                                if (rename($dir.'/'.$file, $altpath.'/'.$prefixname))
                                {
                                    $result++;
                                }
                                else {
                                    return "FILE COULD NOT COPIED"; exit;
                                }
                            }     
                        }
                    }
                }//END FIRST WHILE
                closedir($dh);
            }
        }
        else
        {
            return "NOT A DIRECTORY"; exit;
        }
        return $result;
    }

    function crypto_rand_secure($min, $max)
    {
        $range = $max - $min;
        if ($range < 1) return $min; // not so random...
        $log = ceil(log($range, 2));
        $bytes = (int) ($log / 8) + 1; // length in bytes
        $bits = (int) $log + 1; // length in bits
        $filter = (int) (1 << $bits) - 1; // set all lower bits to 1
        do {
            $rnd = hexdec(bin2hex(openssl_random_pseudo_bytes($bytes)));
            $rnd = $rnd & $filter; // discard irrelevant bits
        } while ($rnd > $range);
        return $min + $rnd;
    }

    function get_unique_token($length){
        $unique_token = "";
        $codeAlphabet = "0123456789";
        $max = strlen($codeAlphabet);
    
        for ($i=0; $i < $length; $i++) {
           $unique_token .= $codeAlphabet[random_int(0, $max-1)];
        }
    
       return $unique_token;
    }

    public function get_company_wht_tax_rate($contract_type){
        $rate = 0;

        switch ($contract_type) {
            case (strtolower($contract_type) == "dividends" || strtolower($contract_type) == "dividend" || strtolower($contract_type) == "interest" || strtolower($contract_type) == "rents" || strtolower($contract_type) == "rent"):
                $rate = 10;
                break;
            case (strtolower($contract_type) == "directors fees" || strtolower($contract_type) == "director fees" || strtolower($contract_type) == "directors fee" || strtolower($contract_type) == "director fee"):
                $rate = 0;
                break;
            case (strtolower($contract_type) == "hire of equipment" || strtolower($contract_type) == "equipment hire" || strtolower($contract_type) == "hire"):
                $rate = 10;
                break;
            case (strtolower($contract_type) == "royalties" || strtolower($contract_type) == "royalty"):
                $rate = 10;
                break;
            case (strtolower($contract_type) == "commission" || strtolower($contract_type) == "consultancy" || strtolower($contract_type) == "technical" || strtolower($contract_type) == "service fees" || strtolower($contract_type) == "service"):
                $rate = 10;
                break;
            case (strtolower($contract_type) == "management fees" || strtolower($contract_type) == "management" || strtolower($contract_type) == "management fee"):
                $rate = 10;
                break;
            case (strtolower($contract_type) == "construction"):
                $rate = 2.5;
                break;
            case (strtolower($contract_type) == "contracts" || strtolower($contract_type) == "contract" || strtolower($contract_type) == "supply" || strtolower($contract_type) == "service" || strtolower($contract_type) == "supplies" || strtolower($contract_type) == "services"):
                $rate = 5;
                break;
            default:
                $rate = 5;
        }

        return $rate;
    }
}
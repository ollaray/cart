<?php

class Page_model extends CI_Model{

  protected $_table;
    
  function __construct() {
      parent::__construct();
  }

  public function coupon_list(){
    $query = $this->db->query("SELECT a.id, a.coupon_code, a.descrp, b.discount_type FROM tbl_coupons a INNER JOIN tbl_discount_type b ON a.discount_type = b.id ORDER BY CAST(a.created AS SIGNED)");

    $arr = array();

    if($query->num_rows()> 0)
    {
      $i=0;
      foreach($query->result() as $row):
          $arr[$i]['id'] = $row->id;
          $arr[$i]['coupon_code'] = $row->coupon_code;
          $arr[$i]['descrp'] = strtoupper($row->descrp);
          $arr[$i]['discount_type'] = strtoupper($row->discount_type);
        ++$i;
      endforeach;
      return $arr;
    }
    return false;
  }

  public function get_discount_type(){
    $query = $this->db->query("SELECT id, discount_type FROM tbl_discount_type WHERE `status` = 1 ORDER BY CAST(id AS SIGNED)")->result();
    return $query;
  }

  public function verify_coupon_code($coupon_code){
    $arr = array();

    $query = $this->db->query("SELECT coupon_code FROM tbl_coupons WHERE `status` = 1 AND TRIM(coupon_code) = '$coupon_code'");

    if($query->num_rows() > 0){
      return true;
    }
    else{
      return false;
    }
  }
}
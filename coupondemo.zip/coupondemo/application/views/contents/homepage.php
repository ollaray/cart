<!-- Hero Slider -->
<section class="hero-slider style1">
	<div class="home-slider">
		<!-- Single Slider -->
		<div class="single-slider" style="background-image:url('<?=base_url('assets/img/slider-image/slider-image11.jpg'); ?>')">
			<div class="container">
				<div class="row">
					<div class="col-lg-7 col-md-8 col-12">
						<div class="welcome-text"> 
							<div class="hero-text">
								<h1>Your Savings. Your Investment. Your Future.</h1>
								<h4>Build your desired future through savings and investment</h4>
								<!-- <h4>Your Savings. Your Investment. Your Future.</h4> -->
								<!-- <h1>Build Your WorldClass Brand with Bizwheel</h1> -->
								<!-- <div class="p-text">
									<p>Build your desired future through savings and investment</p>
								</div> -->
								<!-- <div class="button">
									<a href="contact.html" class="bizwheel-btn theme-1 effect">Work with us</a>
									<a href="portfolio.html" class="bizwheel-btn theme-2 effect">View Our Portfolio</a>
								</div> -->
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!--/ End Single Slider -->
		<!-- Single Slider -->
		<div class="single-slider" style="background-image:url('<?=base_url('assets/img/slider-image/slider-image2.jpg'); ?>')">
			<div class="container">
				<div class="row">
					<div class="col-lg-7 col-md-8 col-12">
						<div class="welcome-text"> 
							<div class="hero-text">
								<h1>Creative and Professional Support</h1>
								<h4>We make your dreams come through by helping you grow with ease</h4>
								<!-- <div class="p-text">
									<p>We make your dreams come through by helping you grow with ease</p>
								</div> -->
								<!-- <div class="button">
									<a href="https://www.themelamp.com/tf/bizwheel/blog.html" class="bizwheel-btn theme-1 effect">Read our blog</a>
								</div> -->
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!--/ End Single Slider -->
		<!-- Single Slider -->
		<div class="single-slider" style="background-image:url('<?=base_url('assets/img/slider-image/slider-image3.jpg'); ?>')">
			<div class="container">
				<div class="row">
					<div class="col-lg-7 col-md-8 col-12">
						<div class="welcome-text"> 
							<div class="hero-text"> 
								<h1>Transparency and Accountability</h1>
								<h4>Quality traits that will value and promote</h4>
								<!-- <h4>Transparency and Accountability</h4> -->
								<!-- <h1>Best Way to Represent your Next Business </h1> -->
								<!-- <div class="p-text">
									<p>Quality trait that will value and promote</p>
								</div> -->
								<!-- <div class="button">
									<a href="team.html" class="bizwheel-btn theme-2 effect">Our Leaders</a>
								</div> -->
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!--/ End Single Slider -->
	</div>
</section>
<!--/ End Hero Slider -->

<!-- Features Area -->
<section class="features-area section-bg">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-12">
				<!-- Single Feature -->
				<div class="single-feature" style="height: 250px;overflow: hidden;">
					<h4><a href="https://www.themelamp.com/tf/bizwheel/service-single.html">Welcome to NNPC - PPMC Mosimi</a></h4>
					<p style="text-align:justify;">NNPC Staff Cooperative Multipurpose Society Limited is registered under the Cooperative Law of Lagos State and was founded in 1979 with the sole objective of providing quality and efficient services to her members, anchored on improving their economic and social well being.</p>
					<p style="text-align:justify; margin-top:10px;">The society started operation with membership strength of about 20 members but today has grown to over 6000 members spread across the federation. The cooperative draws its members from staff of the Nigerian National Petroleum Corporation (NNPC), its various subsidiaries, Department of Petroleum Resources (DPR) and the Petroleum Technology Development (PTDF). The memberships from these Organizations are the three levels of management (Top, Middle, lower and other categories of staff) in various locations where Oil and Gas operations are carried out in the country. <a href="<?=site_url('Pages/aboutus'); ?>"> View More »</a></p>
				</div>
				<!--/ End Single Feature -->
			</div>
			<!-- <div class="col-lg-4 col-md-6 col-12 divnews"> -->
				<!-- Single Feature -->
				<!-- <div class="single-feature divnews-slide" style="height: 350px !important; overflow: hidden;"> -->
					<!-- <marquee behavior="scroll" align="left" direction="up" scrollamount="2" scrolldelay="10" onmouseover="this.stop()" onmouseout="this.start()" height="200"> -->
					<!-- <ul>
					<?php if(isset($news)): ?>
						<?php foreach($news as $row): ?>
						<li style="margin: 10px 0px; border-bottom: 1px solid #ccc;">
							<h4 style="font-size: 14px; text-align:left; margin: 7px 0;"><?=strtoupper($row->title); ?></h4>
							<p style="font-size: 14px; text-align:justify; font-weight: normal; text-transform:none"><?=$row->summary; ?> 
							<?php if(!empty($row->body)){ ?>
								<a href="#">Read more</a>
							<?php } ?>
							</p>
						</li>
						<?php endforeach; ?>
					<?php endif; ?>
					</ul>
				</div> -->
				<!--/ End Single Feature -->
			<!-- </div> -->
		</div>
	</div>
</section>
<!--/ End Features Area -->

<!-- Call To Action -->
<section class="call-action overlay" style="background-image:url('img/cta-bg.jpg')">
	<div class="container">
		<div class="row">
			<div class="col-lg-9 col-12">
				<div class="call-inner">
					<h2>Our Vision</h2>
					<p>To be a universally acceptable Cooperative Society in Wealth Creation through Competent Management.</p>
				</div>
			</div>
			<div class="col-lg-3 col-12">
				<div class="button">
					<a href="<?=site_url('Pages/vision'); ?>" class="bizwheel-btn">Learn more</a>
				</div>
			</div>
		</div>
	</div>
</section>
<!--/ End Call to action -->

<!-- Services -->
<section class="services section-bg section-space">
	<div class="container">
		<div class="row">
			<div class="col-lg-4 col-md-4 col-12">
				<!-- Single Service -->
				<div class="single-service">
					<div class="service-head">
						<h4 style="text-align:center; line-height: 22px; padding:15px 10px;"><a href="#">10<sup>th</sup> AGM (MANAGEMENT REPORT)</a></h4>
					</div>
					<div class="service-content">
						<p style="text-align:center"><a href="<?=base_url('assets/img/publications/2019 AGM report (2020).pdf'); ?>"><img src="<?=base_url('assets/img/events/agm.jpg'); ?>" alt="AGM" width="175" height="250" /></a></p>
					</div>
				</div>
				<!--/ End Single Service -->
			</div>
			<div class="col-lg-4 col-md-4 col-12">
				<!-- Single Service -->
				<div class="single-service">
					<div class="service-head">
						<h4 style="text-align:center; line-height: 22px; padding:15px 10px;"><a href="#">FAQ</a></h4>
						<p style="text-align:center; padding: 5px;">Have any question for us?</p>
					</div>
					<div class="service-content">
						<div class="row">
							<div class="col-lg-4 col-md-4 col-6">
								<!-- Single List Feature -->
								<div class="single-list-feature">
									<i class="fa fa-phone"></i>
								</div>
								<!--/ End Single List Feature -->
							</div>
							<div class="col-lg-4 col-md-4 col-6">
								<!-- Single List Feature -->
								<div class="single-list-feature">
									<i class="fa fa-comments-o"></i>
								</div>
								<!--/ End Single List Feature -->
							</div>
							<div class="col-lg-4 col-md-4 col-6">
								<!-- Single List Feature -->
								<div class="single-list-feature">
									<i class="fa fa-envelope-o"></i>
								</div>
								<!--/ End Single List Feature -->
							</div>	
						</div>
						<p style="padding: 10px 0px; word-wrap: break-word;" ><b>Email: </b>mosimicoopsociety@yahoo.com</p>
						<!-- <p style="padding: 10px 0px; word-wrap: break-word;"><b>Facebook: </b>https://www.facebook.com/nnpccms</p> -->
						<p style="padding: 10px 0px; word-wrap: break-word;"><b>Phone: </b>+2348187933898</p>
					</div>
				</div>
				<!--/ End Single Service -->
			</div>
			<div class="col-lg-4 col-md-4 col-12">
				<!-- Single Service -->
				<div class="single-service">
					<div class="service-head">
						<h4 style="text-align:center; line-height: 22px; padding:15px 10px;"><a href="#">Membership Population</a></h4>
						<p style="text-align:center; padding: 5px;">We invite you to join us today.</p>
					</div>
					<div class="service-content" style="padding: 10px;">
						<p style="text-align:center; padding: 10px 0px; "><img src="<?=base_url('assets/img/events/membership.jpg'); ?>" alt="Membership" style="height: 150px; width:auto;" /></p>
						<p style="text-align:center; padding: 5px 0px; "><b>Membership Population: </b>7494</p>
						<p style="text-align:center; padding: 5px 0px; "><a href="http://nnpcmosimicoop.5emms.com/membereg.aspx" target="_blank" class="bizwheel-btn">Member Registration</a></p>
					</div>
				</div>
				<!--/ End Single Service -->
			</div>
		</div>
	</div>
</section>
<!--/ End Services -->

<!-- Our Team -->
<section class="team section-bg section-space">
	<div class="container">
		<div class="row">
			<div class="col-12">
				<div class="section-title  style2 text-center">
					<div class="section-top">
						<h1><b>Our Executives Team</b></h1>
					</div>
				</div>
			</div>
		</div>
		<div class="team-slider">
			<?php if(!empty($officials)): ?>
				<?php foreach($officials as $row): ?>
				<div class="single-slider">
					<!-- Single Team -->
					<div class="single-team">
						<div class="team-head">
							<img 
								<?php if(!empty($row->exco_pic)): ?>
									src="<?=base_url('assets/img/team/'.$row->exco_pic); ?>"
								<?php else: ?>
									src="<?=base_url('assets/img/defaultimg.png'); ?>"
								<?php endif; ?>
								alt="<?= $row->post_held;?>" style="width:397px; height:384px;">
						</div>
						<div class="t-content">
							<div class="content-inner">
								<h4 class="name"><a href="#"><?= $row->exco_name;?></a></h4>
								<span class="designation"><?= $row->post_held;?></span>
							</div>
						</div>
					</div>
					<!--/ End Single Team -->
				</div>
				<?php endforeach; ?>
			<?php endif; ?>
		</div>
	</div>
</section>
<!--/ End Team -->
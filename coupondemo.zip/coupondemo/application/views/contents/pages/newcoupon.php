<div class="row">
    <div class="col-sm-12">
        <div class="white-box">
            <span class="requiredstar" style="color:#FF0000; font-size:14px;">* required field</span>
            
            <div class="table-responsive">
                <form class="form" id="frmsaverec"  method="post" enctype="multipart/form-data">
                    <div class="form-group mt-5 row">
                        <label for="example-text-input" class="col-2 col-form-label">Coupon Code <span class="requiredstar">*</span></label>
                        <div class="col-4">
                            <input class="form-control" type="text" id="txtcouponcode" name="txtcouponcode" />
                        </div>
                        <div class="col-6">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="example-search-input" class="col-2 col-form-label">Coupon Name <span class="requiredstar">*</span></label>
                        <div class="col-10">
                            <input class="form-control" type="text" id="txtcouponname" name="txtcouponname" />
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="seldiscountype" class="col-2 col-form-label">Discount Type <span class="requiredstar">*</span></label>
                        <div class="col-4">
                            <select id="seldiscountype"  name="seldiscountype" class="form-control select2_single" style="width:100%;">
                                <option value="">--SELECT--</option>
                                <?php if(isset($discount_type)):
                                foreach($discount_type as $row):
                                    echo'<option value="'.$row->id.'">'.strtoupper($row->discount_type).'</option>';
                                endforeach;
                                endif; 
                                ?>
                            </select>
                        </div>
                        <div class="col-6">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="txtdiscount1" class="col-2 col-form-label" id="discount1">Fixed Amount <span class="requiredstar">*</span></label>
                        <div class="col-4">
                            <input class="form-control" type="text" id="txtdiscount1" name="txtdiscount1" />
                        </div>
                        <label for="txtdiscount2" class="col-2 col-form-label discount2" style="visibility:hidden">Percentage Value <span class="requiredstar">*</span></label>
                        <div class="col-4 discount2" style="visibility:hidden">
                            <input class="form-control" type="text" id="txtdiscount2" name="txtdiscount2" />
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="txtmincartamount" class="col-2 col-form-label" >Minimum Cart Amount</label>
                        <div class="col-4">
                            <input class="form-control" type="text" id="txtmincartamount" name="txtmincartamount" />
                        </div>
                        <label for="txtmincartitem" class="col-2 col-form-label">Minimum Cart Item</label>
                        <div class="col-4">
                            <input class="form-control" type="text" id="txtmincartitem" name="txtmincartitem" />
                        </div>
                    </div>
                        <div class="form-actions">
                            <div class="card-body">
                                <input id="seenfr" name="seenfr" type="hidden" value="1" />
                                <button type="button" class="btn btn-success" id="btncreatecoupon"> <i class="fa fa-check"></i> Create Coupon</button>
                                <button type="reset" class="btn btn-dark">Cancel</button>
                            </div>
                        </div>
                </form>
            </div>
        </div>
    </div>
</div>
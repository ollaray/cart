<div class="row">
    <div class="col-sm-8">
        <div class="white-box">
            <h3 class="box-title" id="itemcart">Cart Items(5)</h3>
            
            <div class="table-responsive">
                <table class="table">
                    <tbody>
                        <tr>
                            <td><img src="<?=site_url('assets/img/products/1.jpg'); ?>" alt="user-img" width="100" ></td>
                            <td>
                                <div class="form-group mb-4">
                                    <label class="col-md-12 p-0"><strong>Best Friends Love Heart Couple Necklace</strong></label>
                                    <h5 class="text-muted mb-0"><strong>Price: </strong>&#8358; <span id="itemcart1">1500</span></h5>
                                    
                                </div>
                            </td>
                            <td style="vertical-align:middle; text-align:center;">
                                <button class="btn btn-danger btn-circle btn-lg">
                                    <i class="fas fa-minus-square"></i>
                                </button>
                            </td>
                        </tr>
                        <tr>
                            <td><img src="<?=site_url('assets/img/products/2.jpg'); ?>" alt="user-img" width="100" ></td>
                            <td>
                                <div class="form-group mb-4">
                                    <label class="col-md-12 p-0"><strong>V9 Ear Bluetooth Wireless CSR Noise Cancelling Headset Portable Earphone</strong></label>
                                    <h5 class="text-muted mb-0"><strong>Price: </strong>&#8358; <span id="itemcart2">3200</span></h5>
                                    
                                </div>
                            </td>
                            <td style="vertical-align:middle; text-align:center;">
                                <button class="btn btn-danger btn-circle btn-lg">
                                    <i class="fas fa-minus-square"></i>
                                </button>
                            </td>
                        </tr>
                        <tr>
                            <td><img src="<?=site_url('assets/img/products/3.jpg'); ?>" alt="user-img" width="100" ></td>
                            <td>
                                <div class="form-group mb-4">
                                    <label class="col-md-12 p-0"><strong>Six Pairs-in-1 Quality Ankle Socks</strong></label>
                                    <h5 class="text-muted mb-0"><strong>Price: </strong>&#8358; <span id="itemcart3">1200</span></h5>
                                    
                                </div>
                            </td>
                            <td style="vertical-align:middle; text-align:center;">
                                <button class="btn btn-danger btn-circle btn-lg">
                                    <i class="fas fa-minus-square"></i>
                                </button>
                            </td>
                        </tr>
                        <tr>
                            <td><img src="<?=site_url('assets/img/products/4.jpg'); ?>" alt="user-img" width="100" ></td>
                            <td>
                                <div class="form-group mb-4">
                                    <label class="col-md-12 p-0"><strong>Leather Belt - Black</strong></label>
                                    <h5 class="text-muted mb-0"><strong>Price: </strong>&#8358; <span id="itemcart4">2900</span></h5>
                                    
                                </div>
                            </td>
                            <td style="vertical-align:middle; text-align:center;">
                                <button class="btn btn-danger btn-circle btn-lg">
                                    <i class="fas fa-minus-square"></i>
                                </button>
                            </td>
                        </tr>
                        <tr>
                            <td><img src="<?=site_url('assets/img/products/5.jpg'); ?>" alt="user-img" width="150" ></td>
                            <td>
                                <div class="form-group mb-4">
                                    <label class="col-md-12 p-0"><strong>Men's Slip-on Sneakers - Black</strong></label>
                                    <h5 class="text-muted mb-0"><strong>Price: </strong>&#8358; <span id="itemcart5">2590</span></h5>
                                    
                                </div>
                            </td>
                            <td style="vertical-align:middle; text-align:center;">
                                <button class="btn btn-danger btn-circle btn-lg">
                                    <i class="fas fa-minus-square"></i>
                                </button>
                            </td>
                        </tr>
                    </tbody>
                </table>
                <span id="itemcount">5</span>
            </div>
        </div>
    </div>

    <div class="col-sm-4">
        <div class="white-box">
            <h3 class="box-title">Shop Summary</h3>
            
            <div class="table-responsive">
                <table class="table">
                    <tbody>
                        <tr>
                            <td>
                                <div class="form-group mb-4">
                                    <label class="col-md-12 p-0">Sub Total</label>
                                    <h5 class="text-muted mb-0">&#8358; <span id="spnsubtotal">11390</span></h5>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <div class="input-group mb-3">
                                    <input type="text" class="form-control" placeholder="Enter Coupon Code" aria-label="" aria-describedby="basic-addon1">
                                    <div class="input-group-append">
                                        <button class="btn btn-info" type="button">Apply Coupon</button>
                                    </div>
                                </div>
                                <div class="form-group mb-4">
                                    <label class="col-md-12 p-0">Discount</label>
                                    <h5 class="text-muted mb-0">&#8358; <span id="spndiscount">0.00</span></h5>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <div class="form-group mb-4">
                                    <label class="col-md-12 p-0">Grand Total</label>
                                    <h5 class="text-muted mb-0">&#8358; <span id="spntotal">11390</span></h5>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
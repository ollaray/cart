<div class="row">
    <div class="col-sm-12">
        <div class="white-box">
            
            <a href="<?=site_url('Pages/newcoupon');?>" role="button" class="btn waves-effect waves-light btn-primary">Create Coupon</a>
            
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th class="border-top-0" style="width: 5%;">#</th>
                            <th class="border-top-0" style="width: 20%;">Coupon Code</th>
                            <th class="border-top-0" style="width: 50%;">Coupon Name</th>
                            <th class="border-top-0" style="width: 25%;">Type</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $resultstr = "";
                            if (!empty($record_list)) {
                                $i=1;
                                for($j = 0; $j < count($record_list); ++$j) {
                                    $resultstr .= '<tr style="font-size: 11px;">';
                                    $resultstr .= '<td class="lblrowid" style="padding:4px; position: relative; text-align:center; vertical-align:middle;"> '.$i++.'</td>';
                                    $resultstr .= '<td style="padding:4px; position: relative; vertical-align:middle;"text-align: left;> '.$record_list[$j]['coupon_code'].'</td>';
                                    $resultstr .= '<td style="padding:4px; position: relative; vertical-align:middle;"text-align: left;> '.$record_list[$j]['descrp'].'</td>';
                                    $resultstr .= '<td style="padding:4px; position: relative; vertical-align:middle;"text-align: left;> '.$record_list[$j]['discount_type'].'</td>';
                                    $resultstr .= '</tr>';
                                }
                            }
                            else {
                                $resultstr .= '<tr style="font-size: 15px;">';
                                $resultstr .= '<td colspan="3" style="padding:4px; vertical-align:middle;">NO COUPON HAS BEEN CREATED!</td>';
                                $resultstr .= '</tr>';
                            }

                            echo $resultstr;
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>